# PS4JB

This is an Offline full chain exploit for PS4 firmware 6.72.

## Credits

* [Fire30](https://github.com/Fire30/bad_hoist) for the WebKit exploit
* [TheFlow](https://hackerone.com/reports/826026) for the kernel exploit
* [sleirsgoevy](https://github.com/sleirsgoevy/ps4jb) for the PS4 6.72 JB

## Donate Me

www.paypal.me/darkmodder
